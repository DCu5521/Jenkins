// public interface InterfaceWithAnnotation {
public interface Test136 {
  @Deprecated
  public static final String MY_PARAM = "param";
}
