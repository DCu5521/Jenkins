public class MainJMenuBar extends JMenuBar {
    public MainJMenuBar(Vector vMenu_) {
        super((String)vMenu_.elementAt(0));
    }
}
