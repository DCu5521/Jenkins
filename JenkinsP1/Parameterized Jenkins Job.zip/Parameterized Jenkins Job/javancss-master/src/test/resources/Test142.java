package testPackage;


public interface TestInterface {

    /**
     *
     * @author
     */
    @Deprecated
    public static class TestClass {


    }
}
