package test;

import nothing;

public class Something1 {
    public Something1() {
        super();
    }

    public void sleep();

    public void run() {
        int i = 5;
    }
}
// ncss = 8
package test;

import nothing;

public class Something2 {
    public Something2() {
        super();
    }

    public void sleep();

    public void run() {
        int i = 5;
    }
}
// ncss = 16
