public class Test16 {
    public static void filter()    {
        Predicate pFilter = new Predicate() {
            public void test(Object pObject_) {
            }
        };
    }
}
