package test;
public class Test147 {
Object fe = new Object() {
public String toString() {
  return "";
}
};
Object fe2 = new Object() {
public String toString() {
  return "";
}
};
public class test2{
public void test(){
fe.toString();
return;
}
}
}
