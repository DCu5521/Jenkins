public class Test36 {
}//