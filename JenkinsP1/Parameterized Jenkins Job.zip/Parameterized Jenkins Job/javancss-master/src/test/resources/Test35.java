public class Test35 {
  }